

#include <WiFi.h>
#include <PubSubClient.h>
#include <Wire.h>
#include <ArduinoJson.h>
#include <math.h>

// ── WiFi ─────────────────────────────────────────────────────
const char* WIFI_SSID     = "Wokwi-GUEST";
const char* WIFI_PASSWORD = "";

// ── MQTT Broker ──────────────────────────────────────────────
const char* MQTT_BROKER   = "broker.hivemq.com";
const int   MQTT_PORT     = 1883;
const char* MQTT_CLIENT   = "SmartHelmet_Wokwi_01";
const char* TOPIC_TELE    = "smarthelmet/telemetry";
const char* TOPIC_ALERT   = "smarthelmet/accident";
const char* TOPIC_STATUS  = "smarthelmet/status";

// ── PINS (fixed to match diagram.json) ───────────────────────
#define SDA_PIN         21
#define SCL_PIN         22
#define BUZZER_PIN       2
#define BTN_CANCEL       4    // LEFT  green button → cancel alert
#define BTN_VIB         18    // RIGHT green button → simulate vibration
#define FSR_PIN         34    // Potentiometer      → simulate FSR pressure
#define LED_GPS         32    // Green LED → GPIO 32 (was wrong as 13 before)
#define LED_ACCIDENT    12    // Red LED   → GPIO 12

// ── MPU6050 ──────────────────────────────────────────────────
#define MPU_ADDR        0x68

// ── Thresholds ───────────────────────────────────────────────
#define ACCEL_THRESH    2.5f
#define TILT_THRESH     60.0f
#define CANCEL_MS       10000

// ── GPS hardcoded (Nagpur) ────────────────────────────────────
float gpsLat = 21.145800;
float gpsLng = 79.088200;

// ── State ─────────────────────────────────────────────────────
WiFiClient   wifiClient;
PubSubClient mqtt(wifiClient);

bool accidentActive = false;
int  sampleCount    = 0;
int  frameCount     = 0;

// Pre-accident rolling buffer (10 samples)
struct Sample {
  float accel, tilt;
  int   pressure, vibration;
  unsigned long ts;
};
Sample preBuffer[10];
int preIdx = 0;

// ════════════════════════════════════════════════════════════
void setup() {
  Serial.begin(115200);
  Wire.begin(SDA_PIN, SCL_PIN);

  pinMode(BUZZER_PIN,    OUTPUT);
  pinMode(BTN_CANCEL,    INPUT_PULLUP);
  pinMode(BTN_VIB,       INPUT_PULLUP);
  pinMode(LED_GPS,       OUTPUT);
  pinMode(LED_ACCIDENT,  OUTPUT);
  digitalWrite(BUZZER_PIN,   LOW);
  digitalWrite(LED_ACCIDENT, LOW);
  digitalWrite(LED_GPS,      LOW);

  initMPU6050();
  connectWiFi();

  mqtt.setServer(MQTT_BROKER, MQTT_PORT);
  mqtt.setBufferSize(512);
  connectMQTT();

  // Blink green LED 4 times = system ready
  // Note: GPS module (NEO-6M) not available in Wokwi
  // Green LED on GPIO32 simulates GPS lock indicator
  for (int i = 0; i < 4; i++) {
    digitalWrite(LED_GPS, HIGH); delay(150);
    digitalWrite(LED_GPS, LOW);  delay(150);
  }
  digitalWrite(LED_GPS, HIGH); // stays ON = GPS locked

  publishStatus("ONLINE", "Smart Helmet system started");

  Serial.println("\n==============================================");
  Serial.println("  Smart Helmet — Wokwi MQTT Live Simulation");
  Serial.println("----------------------------------------------");
  Serial.println("  TO TRIGGER ACCIDENT:");
  Serial.println("  1. MPU6050 -> Accel X=4.5, Accel Z=0.1");
  Serial.println("  2. Press RIGHT button (GPIO18)");
  Serial.println("  3. Watch Node-RED + ThingsBoard!");
  Serial.println("==============================================\n");
}

// ════════════════════════════════════════════════════════════
void loop() {
  if (!mqtt.connected()) connectMQTT();
  mqtt.loop();

  // Read sensors
  float accelMag, tiltAngle;
  readMPU6050(accelMag, tiltAngle);

  int  pressure  = analogRead(FSR_PIN) / 4;
  bool vibration = (digitalRead(BTN_VIB) == LOW);

  // Tiny GPS drift
  gpsLat += (float)(random(-5, 5)) * 0.000001f;
  gpsLng += (float)(random(-5, 5)) * 0.000001f;

  sampleCount++;
  frameCount++;

  // Save to rolling pre-accident buffer
  preBuffer[preIdx] = { accelMag, tiltAngle, pressure, vibration ? 1 : 0, millis() };
  preIdx = (preIdx + 1) % 10;

  // Evaluate accident conditions
  bool highAccel = (accelMag  > ACCEL_THRESH);
  bool highTilt  = (tiltAngle > TILT_THRESH);
  bool vibHit    = vibration;
  bool accident  = highAccel && highTilt && vibHit;

  // ── Build and publish telemetry to MQTT ─────────────────
  StaticJsonDocument<300> doc;
  doc["acceleration"] = round(accelMag  * 100) / 100.0;
  doc["tilt_angle"]   = round(tiltAngle * 10)  / 10.0;
  doc["vibration"]    = vibration ? 1 : 0;
  doc["pressure"]     = pressure;
  doc["latitude"]     = gpsLat;
  doc["longitude"]    = gpsLng;
  doc["accident"]     = accident;
  doc["severity"]     = accident ? (accelMag > 4.0 ? "HIGH" : "MEDIUM") : "NORMAL";
  doc["frame"]        = frameCount;
  doc["device_id"]    = "SmartHelmet_Wokwi";

  char buf[300];
  serializeJson(doc, buf);
  mqtt.publish(TOPIC_TELE, buf, false);

  // ── Serial Monitor output ────────────────────────────────
  Serial.printf("[t=%03d] accel=%.2fg | tilt=%.1fdeg | vib=%d | fsr=%d",
    sampleCount, accelMag, tiltAngle, vibration ? 1 : 0, pressure);
  Serial.printf("  [A:%s T:%s V:%s]",
    highAccel ? "HIT" : "ok",
    highTilt  ? "HIT" : "ok",
    vibHit    ? "HIT" : "ok");
  if (accident) Serial.print("  <<< ACCIDENT!");
  Serial.println();

  // ── Handle accident ──────────────────────────────────────
  if (!accidentActive && accident) {
    handleAccident(accelMag, tiltAngle, pressure);
  }

  delay(1000);
}

// ════════════════════════════════════════════════════════════
//  ACCIDENT HANDLER
// ════════════════════════════════════════════════════════════
void handleAccident(float accel, float tilt, int pressure) {
  accidentActive = true;
  digitalWrite(LED_ACCIDENT, HIGH);

  Serial.println();
  Serial.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
  Serial.println("!!        ACCIDENT DETECTED             !!");
  Serial.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
  Serial.printf("  Acceleration : %.2f g\n",   accel);
  Serial.printf("  Tilt Angle   : %.1f deg\n", tilt);
  Serial.println("  Vibration    : DETECTED");
  Serial.printf("  Pressure     : %d\n",       pressure);
  Serial.printf("  GPS          : %.6f, %.6f\n", gpsLat, gpsLng);
  Serial.println();

  // Print pre-accident buffer
  Serial.println("[CAMERA] Pre-accident frames (last 10 seconds):");
  for (int i = 0; i < 10; i++) {
    int idx = (preIdx + i) % 10;
    Serial.printf("  pre_%02d.jpg | accel=%.2fg | tilt=%.1fdeg\n",
      i + 1, preBuffer[idx].accel, preBuffer[idx].tilt);
  }
  Serial.println();

  // Buzzer alert
  buzzPattern();
  Serial.println("[BUZZER] Active — Press LEFT button (GPIO4) within 10s to cancel");

  // Wait for cancel
  unsigned long start     = millis();
  bool          cancelled = false;

  while (millis() - start < CANCEL_MS) {
    mqtt.loop();
    if (digitalRead(BTN_CANCEL) == LOW) {
      cancelled = true;
      digitalWrite(BUZZER_PIN, LOW);
      Serial.println("[CANCEL] Alert cancelled by rider.");
      publishStatus("CANCELLED", "Rider cancelled alert");
      break;
    }
    digitalWrite(LED_ACCIDENT, (millis() / 400) % 2);
    delay(50);
  }

  digitalWrite(BUZZER_PIN, LOW);

  if (!cancelled) {
    Serial.println("[ALERT] Sending emergency MQTT alert...");

    // Build accident payload
    StaticJsonDocument<400> alert;
    alert["ACCIDENT"]     = true;
    alert["acceleration"] = round(accel * 100) / 100.0;
    alert["tilt_angle"]   = round(tilt  * 10)  / 10.0;
    alert["vibration"]    = 1;
    alert["pressure"]     = pressure;
    alert["latitude"]     = gpsLat;
    alert["longitude"]    = gpsLng;
    alert["severity"]     = accel > 4.0 ? "HIGH" : "MEDIUM";
    alert["device_id"]    = "SmartHelmet_Wokwi";
    alert["maps_link"]    = "https://maps.google.com/?q=21.145800,79.088200";
    alert["message"]      = "ACCIDENT DETECTED - Emergency Alert";

    char alertBuf[400];
    serializeJson(alert, alertBuf);

    // Publish 3 times for reliability
    for (int i = 0; i < 3; i++) {
      mqtt.publish(TOPIC_ALERT, alertBuf, false);
      mqtt.publish(TOPIC_TELE,  alertBuf, false);
      delay(300);
    }

    Serial.println("[MQTT] Published to: smarthelmet/accident");
    Serial.println("[MQTT] Payload:");
    serializeJsonPretty(alert, Serial);
    Serial.println();

    // Post-accident frames
    Serial.println("[CAMERA] Capturing 10 post-accident frames:");
    for (int i = 1; i <= 10; i++) {
      float decayAccel = max(0.5f, accel - (i * 0.38f));
      float decayTilt  = max(10.0f, tilt  - (i * 7.0f));
      Serial.printf("  post_%02d.jpg | accel=%.2fg | tilt=%.1fdeg\n",
        i, decayAccel, decayTilt);

      StaticJsonDocument<200> post;
      post["acceleration"] = round(decayAccel * 100) / 100.0;
      post["tilt_angle"]   = round(decayTilt  * 10)  / 10.0;
      post["vibration"]    = 1;
      post["pressure"]     = max(100, pressure - i * 60);
      post["latitude"]     = gpsLat;
      post["longitude"]    = gpsLng;
      post["accident"]     = true;
      post["phase"]        = "post";
      post["frame"]        = i;

      char postBuf[200];
      serializeJson(post, postBuf);
      mqtt.publish(TOPIC_TELE, postBuf, false);
      mqtt.loop();
      delay(600);
    }

    Serial.println();
    Serial.println("==========================================");
    Serial.println("  EMERGENCY ALERT SENT SUCCESSFULLY");
    Serial.println("  20 frames logged (10 pre + 10 post)");
    Serial.println("  Check Node-RED debug tab");
    Serial.println("  Check ThingsBoard dashboard");
    Serial.println("==========================================");
  }

  digitalWrite(LED_ACCIDENT, LOW);
  digitalWrite(LED_GPS,      HIGH);
  accidentActive = false;
  Serial.println("\n[SYSTEM] Resuming normal monitoring...\n");
}

// ════════════════════════════════════════════════════════════
//  READ MPU6050
// ════════════════════════════════════════════════════════════
void readMPU6050(float &accelMag, float &tiltAngle) {
  Wire.beginTransmission(MPU_ADDR);
  Wire.write(0x3B);
  Wire.endTransmission(false);
  Wire.requestFrom(MPU_ADDR, 6, true);

  int16_t ax = (Wire.read() << 8) | Wire.read();
  int16_t ay = (Wire.read() << 8) | Wire.read();
  int16_t az = (Wire.read() << 8) | Wire.read();

  float x = ax / 16384.0f;
  float y = ay / 16384.0f;
  float z = az / 16384.0f;

  accelMag  = sqrt(x*x + y*y + z*z);
  tiltAngle = degrees(atan2(sqrt(x*x + y*y), abs(z)));
}

// ════════════════════════════════════════════════════════════
//  WiFi CONNECT
// ════════════════════════════════════════════════════════════
void connectWiFi() {
  Serial.print("[WiFi] Connecting to Wokwi-GUEST");
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  int tries = 0;
  while (WiFi.status() != WL_CONNECTED && tries < 20) {
    delay(500); Serial.print("."); tries++;
  }
  if (WiFi.status() == WL_CONNECTED) {
    Serial.println(" Connected! IP: " + WiFi.localIP().toString());
  } else {
    Serial.println(" FAILED — enable Wokwi IoT Gateway");
  }
}

// ════════════════════════════════════════════════════════════
//  MQTT CONNECT
// ════════════════════════════════════════════════════════════
void connectMQTT() {
  Serial.print("[MQTT] Connecting to broker.hivemq.com");
  int tries = 0;
  while (!mqtt.connected() && tries < 5) {
    if (mqtt.connect(MQTT_CLIENT)) {
      Serial.println(" Connected!");
      mqtt.subscribe(TOPIC_STATUS);
    } else {
      Serial.printf(" failed rc=%d, retrying...\n", mqtt.state());
      delay(2000);
    }
    tries++;
  }
}

// ════════════════════════════════════════════════════════════
//  HELPERS
// ════════════════════════════════════════════════════════════
void publishStatus(const char* status, const char* msg) {
  StaticJsonDocument<128> doc;
  doc["status"]  = status;
  doc["message"] = msg;
  char buf[128];
  serializeJson(doc, buf);
  mqtt.publish(TOPIC_STATUS, buf);
}

void initMPU6050() {
  Wire.beginTransmission(MPU_ADDR);
  Wire.write(0x6B);
  Wire.write(0x00);
  Wire.endTransmission(true);
  Serial.println("[INIT] MPU6050 ready");
}

void buzzPattern() {
  for (int i = 0; i < 5; i++) {
    digitalWrite(BUZZER_PIN, HIGH); delay(350);
    digitalWrite(BUZZER_PIN, LOW);  delay(150);
  }
  digitalWrite(BUZZER_PIN, HIGH);
}